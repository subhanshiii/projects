const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
const io = new Server(server);

// 1. Serve the frontend HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// 2. Handle Socket.io WebSockets connections
io.on('connection', (socket) => {
    console.log('🟢 A user connected via Socket.io');

    // Send a message every 1.5 seconds specifically to this connected client
    let counter = 0;
    const intervalId = setInterval(() => {
        counter++;
        const data = {
            message: `Stock Price Update`,
            price: (Math.random() * 100).toFixed(2),
            time: new Date().toLocaleTimeString()
        };
        
        // Emit a custom event named 'market-data'
        socket.emit('market-data', data);
    }, 1500);

    // Crucial: Clean up if the client disconnects
    socket.on('disconnect', () => {
        console.log('🔴 A user disconnected');
        clearInterval(intervalId);
    });
});

server.listen(3005, () => {
    console.log('🚀 Socket.io Server running at http://localhost:3005');
});
